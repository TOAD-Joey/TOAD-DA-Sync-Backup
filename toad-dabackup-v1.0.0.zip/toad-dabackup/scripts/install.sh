#!/bin/sh
# Created by ToadSoftware.nl

# Functions
function pause() {
    prompt="$1"
    echo -e -n "\033[1;36m$prompt"
    echo -e -n '\033[0m'
    read
}

clear
PLUGINPATH=/usr/local/directadmin/plugins/toad-dabackup
cd ${PLUGINPATH}
 
# Confirm
echo -e "\033[1;36m"
echo -e "   ____    __      ___  _  _  _  _  ___ "
echo -e "  (  _ \  /__\    / __)( \/ )( \( )/ __)"
echo -e "   )(_) )/(__)\   \__ \ \  /  )  (( (__ "
echo -e "  (____/(__)(__)  (___/ (__) (_)\_)\___)"
echo -e "    ToadSoftware.nl	 				 "
echo -e " "
pause "You are about to install the TOAD DA Sync Backup plugin..."
while true; do sleep 0.25 && echo -ne "\r\\" && sleep 0.25 && echo -ne "\r|" && sleep 0.25 && echo -ne "\r/" && sleep 0.25 && echo -ne "\r-"; break; done;
echo " "

# Checking functions
echo -ne "Checking for SSH .."
if [ -e  "/usr/bin/ssh" ]; then
        echo -e "[YES]"
else
        echo -e "[NO]"
        exit
fi
echo -ne "Checking for RSYNC .."
if [ -e  "/usr/bin/rsync" ]; then
        echo -e "[YES]"
else
        echo -e "[NO]"
        exit
fi
echo -ne "Checking for /usr/local/bin/php .."
if [ -e  "/usr/local/bin/php" ]; then
        echo -e "[YES]"
else
        echo -e "[NO]"
        echo -e "I can't find /usr/local/bin/php . Please  build PHP , after that rerun this installation script";
        exit
fi
# Install rsync 3.0
echo -ne "Checking for Rsync 3.0 ............."
if [ -e  "/opt/rsync/bin/rsync" ]; then
        echo -e "[YES]"
else
        echo -e "[NO]"
        echo "Installing Rsync 3.0...."
        wget -c  http://files.syslint.com/src/rsync-3.1.0.tar.gz
        tar -xzf  rsync-3.1.0.tar.gz
        cd rsync-3.1.0/
        ./configure  --prefix=/opt/rsync
        make
        make install
        cd ..
        rm -rf rsync*
fi

echo " "
while true; do sleep 0.25 && echo -ne "\r\\" && sleep 0.25 && echo -ne "\r|" && sleep 0.25 && echo -ne "\r/" && sleep 0.25 && echo -ne "\r-"; break; done;
echo " "

# SSH KEY
echo -n "Installing SSH Public Key..."
mkdir -p ${PLUGINPATH}/.ssh
ssh-keygen -t rsa -f /usr/local/directadmin/plugins/toad-dabackup/.ssh/rsynckey  -N ''

echo " "
while true; do sleep 0.25 && echo -ne "\r\\" && sleep 0.25 && echo -ne "\r|" && sleep 0.25 && echo -ne "\r/" && sleep 0.25 && echo -ne "\r-"; break; done;
echo " "

# Create local backup folder
echo -n "Creating local backup folder..."
mkdir -p /backups
chmod -R 755 /backups
chown -R diradmin:diradmin  /backups

echo " "
while true; do sleep 0.25 && echo -ne "\r\\" && sleep 0.25 && echo -ne "\r|" && sleep 0.25 && echo -ne "\r/" && sleep 0.25 && echo -ne "\r-"; break; done;
echo " "

# CHMOD/CHOWN
chmod -R 755 ${PLUGINPATH}
chown -R diradmin:diradmin ${PLUGINPATH}

chmod -R 777 ${PLUGINPATH}/logs
chown -R diradmin:diradmin ${PLUGINPATH}/logs
 
chmod 644 ${PLUGINPATH}/plugin.conf
chown diradmin:diradmin ${PLUGINPATH}/plugin.conf

chmod 666 ${PLUGINPATH}/config.conf
chown diradmin:diradmin ${PLUGINPATH}/config.conf

echo " "
while true; do sleep 0.25 && echo -ne "\r\\" && sleep 0.25 && echo -ne "\r|" && sleep 0.25 && echo -ne "\r/" && sleep 0.25 && echo -ne "\r-"; break; done;
echo " "

# Install cronjob
echo -n "Installing Cronjob..."
echo "0 3 * * * root /usr/local/bin/php /usr/local/directadmin/plugins/toad-dabackup/scripts/cron.php" > /etc/cron.d/toad-dabackup

echo " "
echo -e "\e[32mSuccessfully installed TOAD DA Backup plugin to DirectAdmin.\e[49m";
echo -ne "\e[37m"

exit 0;
