#!/usr/local/bin/php -c/usr/local/directadmin/plugins/toad-dabackup/includes/php.ini
<?php //0046b
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the website operator. If you are the website operator please use the <a href="http://www.ioncube.com/lw/">ionCube Loader Wizard</a> to assist with installation.');exit(199);

?>
HR+cPrqxbt3/WW5iHosD0bEvVXjtblBPo7+Xog2i8xBYmtUpvfZxG2v8+ApvdJzR+m3ohmFTbhd1
X2fm65CzS6e0CyGnVRLaFcUxaGSlVu276efN8mh3o5OGn9iLeDQ6T1EzgZCsX4IXXFmJfVxmBDhs
z+/UGEb37JtGn7FsKHym1Z7+4Bno8fJ7uLMtlm/3npIyFUwGHKqwGuuo5z0gac9eahUFdYWG5zHh
W0QcNk1k2UkjAupeWEFl9xyIYfn0KQwTUE3LpYzr2XbYibocBMo9qTL6sljXxzSR7tmUWCv6zR3i
j7lT3AGckmoExlzavSFbQs/tRCnqIV2RGpNV9OpRcWSL8Na83VUSA3R2vg1nApa99KB8Cizflvad
HWpTJ6BCLbIihibeGHapNMBbOnMkyOwTmp4BYoF9AynnZbPFnVWx1D5FNiVhNtVEaFCPPaVRWln2
ckHWFTg/4ssGxJYiuyDvQlcp4X8LnoNJB9HH+Fz/X/r+RagrKRyb1/AeFpgspearmvK6+EQ3SQIX
foWr5bj3KmF3ywFyI/2FUYemxHD2ucEgHdk5ffAss6fEym2zqeJJnxWhyIfxHxtMcuftj5laW9n7
3B6zbDlYqPzIE6dLi5zWjKgFQU5eNoL5QhqFGNZcGvFGf/uY2P4IaR4xYWsb2cIRc151V7ncWZY/
0GI+8RSEiOB+vtzLWNRpLdrGbYEODcN7qaXOUkDkKx/sf/ycXPvvkKEWMKZ242Lfw5noaq6PCZPT
+50g3L7/xcBAplXB6V734QB2kVMWZbzk8Ko8yWRqxjwTsahZrTDcEUZjKmNQrVqvLWymMZimv2+Q
18AX3bLzQJtl/Quz5KH89Jq3V/3caz7V9+NiRRLHoYmUToJgKhyzLiMZu3XFXLmZ9H1DJjZSScvh
noa+bmwU8yIKYXv04g0vDBERaav4aAR0R7j15EB52wbJUMXzIR9lI3fXotpZ4t1pbG9+gn6WJTiC
wQTVZfY5y0a71Md1SvY/ibQVjBEd0WjLRc2CvmMXy4E0Gu5Iaw/izFVdST5dLzFl195fEG9XyR/e
ukhqgA+u9GOrtSVDzMjVGsha+JMZUsGkrrllQGn88mYkNrYke8f9lmLi3F1h18w04tNJzt6rWAKX
2KPmXHYhekRJN/XR+G2XavGZ5ZDV50fbsDZu7/9b9u+vnnuSHlPyrL/ocHL/NsbCum8FnAG495PP
DG7GbuQWNyMwB9fsWf8vQpq/yzgjFxeYyZOlxr1ApXJb/zNwVfaurNDJQE1CcngDgaaZY9OYNWdZ
X9oA+LtLuo6Ptn8dnoZbMSJVmg/U2arHcCHfrczN8JFogiiaXN6eEFhwossh8DANfOhf1gTp0cOP
neip+f+749SG3jrUq1c8EikWSZh+7wK0gFRqg+hvSE/Uur/Nk8CEiJ4tWkUNrdnM5Q+INOeBdgRV
VUuABu2GXF2bIy6pLAIib/4GJDfE8x84ARQ8muSj3zkf0BePL/crdqeQH7JOdYzbL1HVPivNOZVe
JPO7pU/1Ee2Vi5HSBrkru2JYNc2R2GtLHQV2/FdEOU+MYE2Mon0OqCLRvKNprxTPllLbf+6fOok/
5aR9J+1QivpFnPLoZ5K2jr8I1N9h3BHdS7a7pD7q6PZr06hHdm/dKQNTXSv6R3O5MnjNmw+5ZJ6K
+H75KYCK2RcNuf/JX8v2aIFERANfrt8wX2Y3Ka88qjFbL2D2Qog2rqVX34c3FIhMWDAVdhllgres
cTkifZjbRzOLh+Y0JSEVSsCfHyN2Ij0UkQHP7h5wAvaF3P0pbh5ixd5mesHbq7jESPt9Fg/yZDQe
KBPWNP0Z+9gFFGI+XrVvzF3GE8rNcUcRC5Rga6YDsWZiM4hH8Id3HRvwVG3c+toF5wrh9SFdq9ie
5sw7KLledYU+0PQdMZy7UaAVo559tGjR2q3r1IwNMEOlxcpQVqgkDDlIaRvNP2zanH+HRJbX8nLo
l8JS25lvlQ/7HV5pNRIiMNNTUutuilHG2GqVTLj5iVwli+VSOO6qDoOpprRtn8ZvdYRKSJgkKbQi
n2yE5tzt4JWUXiGTTyYm+CxhGnpgOhqXecGk