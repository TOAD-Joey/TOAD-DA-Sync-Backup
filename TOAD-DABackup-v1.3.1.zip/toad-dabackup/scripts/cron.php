#!/usr/local/bin/php -c /usr/local/directadmin/plugins/toad-dabackup/includes/php.ini
<?php //0046b
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the website operator. If you are the website operator please use the <a href="http://www.ioncube.com/lw/">ionCube Loader Wizard</a> to assist with installation.');exit(199);

?>
HR+cPmZF91sC5PrINNYnFcdisdIHtU34yipKo/kY3BdlNlblccm011L+NAooCax8OulSfmB0k2fj
iN/i4xaMaPwBDFOzXWP0xUcw2Cp11Y7WSDRV3kjt8R4j9/Uk4lWwB5QCq1FgcEVdCnoPTWHoabKA
3hk04uc26qacyPyvXJNOJspL/C8xheCU6OoNUVqVlTCXzjlQYRrRJ+SsxfNsgSrespWU65FvJWef
WWWxyyBFuioQEtDMkiX+4u5mJ1O6amd2pVp/M2FyhTXsPT6G4sEcbBNQMSIYW9dHDo/SwQrpTVJL
LdWJXyHOeQSvgmpl2fNlrkmDlkmYx74r4AS92jj2+tL2cBZk7dPMNvSpLPMyHTftYFUko/S68lOI
wGAwXJubSHkry12XRCRJ/qo126Rz/fMeaZT+5955nH3oyDe8CSGoJCD13L3Q/rpscAHy7aGZO+yB
ErILjTT3+EpfcBgjXuYOt6tdxRgqhiSw3bMOe5wrRlq3HrESzw5Sql2icyB9IBwurTCdFzngsF7n
TyTg6QZA5EIikKQ+0+JKlN4xZfPCFPKa8GRm885xH6c1yICos2FaeKffaAVZgJRXaoyKnIJi6Qz4
Jt1XE14ZAfmCUm2YizgCiPyDedWY1ShAb9QO7NKNLHZMfiXNgKd+kY9qY5Aq2QV/SyOe9+D/qktc
Vx0fdAEvVytcCN6okRLHDdU67MNGmj7M7PmA6ZgWbx4zsKehPn5wV/g2H/8W+yNuQmv0QfLlcN5K
cHMNoHofmxKa717zymsTItxTMXRy6uoB0WdHmHEyWo5Tj8KlyBlEBJd4I6xMFVlQbFXkZh5KtqZO
c5WUABsktfChhdVfGKpgoLvM4Kj8eJ6DY/u5bsFlw3cRUIzMal03yfKgiD0TirQ4W9qwvSo/YF0J
q8Dw5ZM7AU4HBB8UuNJeCAmtwPEwfc4qo6yvgpwWmrQQ6ZI+a3PneeroUbVMgUAtGF9osbHSAhE8
fA3+3aEGgO58gO4MhC+VKv+ppeWFfAw99Z1TQTfBeh9sPi2GuRWCt7ueaVxzUhIiSLQdU6ZonkPh
muPVPBMLHEYFCo6RjE3OEBpwLYkMf7gz6wOO08Un8gwpZoD3i58u+yXrQdiEjpAQhVntchpdH3z6
C0Bja1Ph8gdVWq89lpai9MRyCSPCimikDeSU7lLjATQKeDgjWvr/RWxfRVHohoJPSKfCdLL8/CXS
mX3XWq7uyEuqXvkqinHOv2JGDTFj95IQbozdfkd/yesmHqzwVR+FTa3Dzasos5kvVFW80ot/TnfP
d+e7tCqplFB2gMH1O5zh9V8NFfQsOJHHMjxImjIM+7Zc+vIoIKLzD0ORJf2QxBAAn2bdgS7+p/Fw
A2QlAl6TOyjAC9Ute7ShHJO0IUrBccfLDSejVix4GdNavukLkZtRhk11hpMnub3rY3U9Lnsv18rU
TlRE0OrDkJLfVD9B7/Qn48W+v2Z5TLiduCS7mDnMK3EFn5cu/7ZnLDCwB+YqYavuKoVx1YNOrzHK
VM/ARe/49RfA191eLKDtK0KxoP9An1v9leh6PtvOfo+B3z4SAk+dkXcXV0DglhHHlU1Dii9L8EWe
yqk/rbclB1FFGuuIuGiACPxs2xyn/30F2CtivkukILfD3xxEoi7tsKUq4h2seBYHrGcLrLNMKimX
c/qJQxL3hKWvWNbz1ZJc2mzK9ftD8Jvp3iQ2Ku1slEqltvok5eVi0JMaLNHoWrJmeBrrBjRxUT3/
T0q46ifhZFIgIs4xsyUVZutlJkIJP0N2Qg0K1O5CRJSGvCrb8P3mp+FXdFQR0jHAmWK/+b3hPw3m
LPmH4maKYo2heGy6D7HSu6jWHPOv69JTj8uPGx0/ZLrvWQ/n8K0lycahA4BemZUMMLTP2y7xJbhy
Mme7UXrfLggwztugzzxbw7YG2chHVvdtHu0uYlSDlp1AlVsbvDTNmLMtjvyh4Jb810YfJYLFA1gl
mANAR5zuRFxZMXRyfsnwsnYKnvpedIilB1tY1zG4DQ6nKVoDiZg/9dWr8cmn2qejNqBvobMWudtz
zxv8qD2KUYBKWO5+RjORotQpJXkVojq3HiDodJr4c0tP3bJL4Q5IYJML4yGjGu/F2M30c3wA3jk1
0tj9e5Xs8ZBb7OZLLVRLDsqn8aCWGjXNK+bEN2FrkueJp8WhaC5odxpNp4vkec7+pZLgahmpYBPS
7ldVT+v/4n9rgqiExDfJM21gDUjeb81kpcJkY1p3D+/bGGXO9RJ0uHZBmfCKuWvHITywTGunt+IU
qvZw9wT77lusKD/46xzpHu4ZJ6O6qDtqMCktP3zy3UQAn53Ote3LQmSOqAwERrQQ5ABw6QJT5MUw
80WOXOWmh4+Vvk5D0rJCkYGJNV4=