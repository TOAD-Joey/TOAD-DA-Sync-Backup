#!/usr/local/bin/php -c /usr/local/directadmin/plugins/toad-dabackup/includes/php.ini
<?php //0046b
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the website operator. If you are the website operator please use the <a href="http://www.ioncube.com/lw/">ionCube Loader Wizard</a> to assist with installation.');exit(199);

?>
HR+cPwngAWZ/IxQkBvBSlojAGSlHiBG/rYQnxzfmlt8KgEOd1JNEOXQMGlKa9tt+md9ZJyXmqVXM
rNd0fS3iK+PgtUrfZLPv1rPb+4iHUX7DbndUWcni1eWbHWiJ8HAym83q8Tky8NDn2uYJAAsXLfc5
GC29Ewd7D2zDkTa5o1/esQbtOxQNcI3QOInvpOmxurIvw1DM2GH6QzOEw/FQzDT9kbNZphVXx7o/
Z+OYlaFnh8LXht4+Xy2dIRrQpsGBQzoSpYiU4avjxRuxPjc8Cd0WjQ2wx/G3caJI9ajAsYySvJ41
7PMoJiqxtLKzSZMcagsy4okfmZxIJHi8fhrjJSwoJu4HBf8OWm7zoLUELVGOi4OcxEzhkmLi5Nyz
LFNXtWXDrjUmU2o6qqbUw8tQLlYzSXP3gKb/yq1bA0FYybuOu+dbAqxjtig5xpHL2UeIgWqFsycr
cHhmZbiYMlONrYNMzYbSpbwoUjGP9kCExq4FRCOo3c0vl5Apvn0nHq8E/CjlI2GFRFYl9edp8rGC
6Zt6WlvIZZhJGGT5C8NgbUSkFWK8S1Z4/Pn5nj0ghXoXObsOrL/LrQYv8qcrClEDJhCfVxdTg2eh
cmBbDXJkgJG3Ms8BZSsyaqzXxKy5RwIlFaeX/o5fz6N2q8MpbOJfuBJvsyV7hTtfJt/kHJ0IdJLr
x66YFkbK8ev4031V42EYXcICPBO0Qeff++kr7S1cTdcPSjfy6M8814E5rC0mZXn7SZiq86PyL3Dj
pQeaKlwkx1wXKxb7vCSEaOXpc6uuoBS8FYoNezPsZFWM0Bloe6UNxNXsXIsFW5TRw2D/DBSpjec3
8Gk0m1qgH0bhzDhmg3a45aI5MF0hI5qSWnL0tt2HLuad/TMsKsoj9GIm+5/Vh8JT47Xzxzkodr9O
TCR//nNU3V7X7MyB1R4YY+HzCBHaJ+5NwCbMtoVtlyGqaNbX2RqU41HdCdpTA63xhxC6J/pfwcA1
qOoKodGPFS2BvhFtXz/zyQfHUlTiaLZT0pbieoVFdHzbLHkCyuks+KpraJLrAAn8TsamZcsluLJ4
+tnA8AI5Ik9mLBv2wbkQzhCA05bsNGB3ttlD+1kdfQWXYKK6GuuSV95YNydEJ1n5tRATaJfATM7T
2DCuv74E6YcGQhV9FGL0Wd1WB4AGzrOEP8h1bQntC3u2Aa29PQ6baJR3d3vwAQY9WiAgQXBMrDNK
SpX1zW/IW8TCK7HyHx4f2PjYbiKMt/q5s+cCg+9zhMqIs4pqyPzXYCR6RAq1NdYdjAff1sIGYrJG
+bo1Usl8BZSHKhia6AJC4SJ3mPIE20ycGxql8ET7ozUYNjQEwZvtcZNSoMLJwoZATcfx9vOokzZD
WzVETWBRKGJ9zlF4KaqJ7Ic41PKMzwiSfE7uER9AtlztNgGA4Ow8aAzyT99CK67vY6mYdUtGOYRR
4ZAZiAX6bpsn+xdwjgLw9iMnGHUlVO7817KVUWUFRXWLQGtut6QO+6MM+ZTci4nhH40CeclcKFsx
6R0nJmN4Riquo51CGjrr0FZ1+ZGDbSJt/MbX0vdN6UxCU0bQRmsyWjiQ8pd7IC+7E6BygrbpicSQ
OG+aJvSqbAKgG/jtx6NMhUiDcJh6dWWsA0yN+yDtILGpEUcd9lIDnzx7K8O0X+KJGAr0mZGxuaBG
4X3ljqAwIbPa1R+cCCwFX8TK+Q1+Gg89GyTLJOB0gSibdAen31Aokz4i5YAKHO0o5YhaKntnuInL
Lw5gt6zDxZE0tqxt0Ga2RgehH/KdM9YfpSL+NRj7n8GTEYrQDThGtyn4bx11Vccx+7ZItZaFmxaZ
pcKO9QnoN219WaQaHElcilnjVhzBHdJTB3YFRq7N7bcWpDAK3BzweLAMVMssuLehbGTjfqunZ5d6
PMMbjPmBMr2NmHydytNvC1QLcC+m7meEMM76+2NTlgZ+BjNx1sVWIdEQN2EC75E1Ri72UsDPSBx1
8puBxWDFqGLcw8/nw6BZx56Igvmi16pTM7Xp5Tfw9nluAZEVmy05y2nNEb6+A+Vlmn86G0Xey+t9
8R2fWZ74kLJW22IQV/VKxv08dODsCCx6iQi9PCVpIE3EyEuYgXHx7gNpJk2KD1f7bHet3buC1aeb
vod/lQPweGUuxHfuCsY+eqIcLlu=