#!/bin/sh

#Remove plugin
rm -rf /usr/local/directadmin/plugins/toad-dabackup

#Remove cronjob
rm -rf /etc/cron.d/toad-dabackup

echo "Sadly the plugin and it's cronjob is removed from DirectAdmin!";
exit 0;
